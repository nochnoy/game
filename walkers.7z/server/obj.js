class Obj {

  constructor() {
    this.id = -1;
    this.url = '';
    this.x = 0;
    this.y = 0;
    this.pivotX = 0;
    this.pivotY = 0;
  }

}

module.exports = Obj;